package net.openvpn.openvpn;
import android.support.v7.app.*;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AlertDialog.Builder;
import android.app.ListActivity;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.*;
import android.view.View.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import java.io.File;
import java.util.*;
import android.widget.AdapterView.*;
import android.support.v7.widget.*;
import zed.freeudp.vpn.*;

public class FileDialog extends AppCompatActivity implements OnItemClickListener{
    public static final String CAN_SELECT_DIR = "CAN_SELECT_DIR";
    public static final String FORMAT_FILTER = "FORMAT_FILTER";
    private static final String ITEM_IMAGE = "image";
    private static final String ITEM_KEY = "key";
    public static final int MODE_CREATE = 0;
    public static final int MODE_OPEN = 1;
    public static final String OPTION_CURRENT_PATH_IN_TITLEBAR = "OPTION_CURRENT_PATH_IN_TITLEBAR";
    public static final String OPTION_ONE_CLICK_SELECT = "OPTION_ONE_CLICK_SELECT";
    public static final String OPTION_PROMPT = "OPTION_PROMPT";
    public static final String RESULT_PATH = "RESULT_PATH";
    private static final String ROOT = "/";
    public static final String SELECTION_MODE = "SELECTION_MODE";
    public static final String START_PATH = "START_PATH";
    private boolean canSelectDir = false;
    private String currentPath = ROOT;
    String[] formatFilter = null;
    private InputMethodManager inputManager;
    private HashMap<String, Integer> lastPositions = new HashMap<String, Integer>();
    private LinearLayout layoutCreate;
    private LinearLayout layoutSelect;
    private ArrayList<HashMap<String, Object>> mList;
    private boolean m_bOneClickSelect = false;
    private boolean m_bTitlebarFolder = false;
    private String parentPath;
    List<String> path = null;
    private Button selectButton;
    private File selectedFile;
    private int selectionMode = MODE_CREATE;
	private ListView listView;
     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(MODE_CREATE, getIntent());
        setContentView(R.layout.file_dialog_main);
		listView = (ListView)findViewById(R.id.list);
		this.layoutSelect = (LinearLayout) findViewById(R.id.fdLinearLayoutSelect);
        this.layoutCreate = (LinearLayout) findViewById(R.id.fdLinearLayoutCreate);
        this.layoutCreate.setVisibility(8);
         listView.setOnItemClickListener(this);
		 
		this.m_bOneClickSelect = getIntent().getBooleanExtra(OPTION_ONE_CLICK_SELECT, this.m_bOneClickSelect);
        this.m_bTitlebarFolder = getIntent().getBooleanExtra(OPTION_CURRENT_PATH_IN_TITLEBAR, this.m_bTitlebarFolder);
        this.selectionMode = getIntent().getIntExtra(FileDialog.SELECTION_MODE, MODE_CREATE);
        this.formatFilter = getIntent().getStringArrayExtra(FileDialog.FORMAT_FILTER);
        this.canSelectDir = getIntent().getBooleanExtra(FileDialog.CAN_SELECT_DIR, false);
      
        this.inputManager = (InputMethodManager) getSystemService("input_method");
        this.selectButton = (Button) findViewById(R.id.fdButtonSelect);
        this.selectButton.setEnabled(false);
        this.selectButton.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                if (FileDialog.this.selectedFile != null) {
                    FileDialog.this.getIntent().putExtra(FileDialog.RESULT_PATH, FileDialog.this.selectedFile.getPath());
                    FileDialog.this.setResult(-1, FileDialog.this.getIntent());
                    FileDialog.this.finish();
                }
            }
        });
        
        
        if (this.selectionMode == MODE_OPEN && this.m_bOneClickSelect) {
            this.layoutSelect.setVisibility(8);
        }
        ((Button) findViewById(R.id.fdButtonCancel)).setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                FileDialog.this.setResult(FileDialog.MODE_CREATE, FileDialog.this.getIntent());
                FileDialog.this.finish();
            }
        });
      
        String startPath = getIntent().getStringExtra(FileDialog.START_PATH);
        if (startPath == null) {
            startPath = ROOT;
        }
        if (this.canSelectDir) {
            this.selectedFile = new File(startPath);
            this.selectButton.setEnabled(true);
        }
        getDir(startPath);
    }

    private void getDir(String dirPath) {
        boolean useAutoSelection = dirPath.length() < this.currentPath.length();
        Integer position = (Integer) this.lastPositions.get(this.parentPath);
        getDirImpl(dirPath);
        if (position != null && useAutoSelection) {
            listView.setSelection(position.intValue());
        }
    }

    private void showLocation(int res_id_prefix, String currentPath) {
        if (this.m_bTitlebarFolder) {
            setTitle(currentPath);
        } else {
            getSupportActionBar().setSubtitle(currentPath);
        }
    }

    private void getDirImpl(String dirPath) {
        this.currentPath = dirPath;
        List<String> item = new ArrayList<String>();
        this.path = new ArrayList<String>();
        this.mList = new ArrayList<HashMap <String, Object>>();
        File f = new File(this.currentPath);
        File[] files = f.listFiles();
        if (files == null) {
            this.currentPath = ROOT;
            f = new File(this.currentPath);
            files = f.listFiles();
        }
        showLocation(R.string.file_dialog_location, this.currentPath);
        if (!this.currentPath.equals(ROOT)) {
            item.add(ROOT);
            addItem(ROOT, R.drawable.file_dialog_folder);
            this.path.add(ROOT);
            item.add("../");
            addItem("../", R.drawable.file_dialog_folder);
            this.path.add(f.getParent());
            this.parentPath = f.getParent();
        }
        TreeMap<String, String> dirsMap = new TreeMap<String,String>();
        TreeMap<String, String> dirsPathMap = new TreeMap<String,String>();
        TreeMap<String, String> filesMap = new TreeMap<String,String>();
        TreeMap<String, String> filesPathMap = new TreeMap<String,String>();
        int length = files.length;
        for (int i = MODE_CREATE; i < length; i += MODE_OPEN) {
            File file = files[i];
            if (file.isDirectory()) {
                String dirName = file.getName();
                dirsMap.put(dirName, dirName);
                dirsPathMap.put(dirName, file.getPath());
            } else {
                String fileName = file.getName();
                String fileNameLwr = fileName.toLowerCase();
                if (this.formatFilter != null) {
                    boolean contains = false;
					try {
                    for (int i2 = MODE_CREATE; i2 < this.formatFilter.length; i2 += MODE_OPEN) {
                        if (fileNameLwr.endsWith(this.formatFilter[i2].toLowerCase())) {
                            contains = true;
                            break;
                        }
                    }
				    } catch (Exception e) {
						
					}
                    if (contains) {
                        filesMap.put(fileName, fileName);
                        filesPathMap.put(fileName, file.getPath());
                    }
                } else {
                    filesMap.put(fileName, fileName);
                    filesPathMap.put(fileName, file.getPath());
                }
            }
        }
        item.addAll(dirsMap.tailMap("").values());
        List<String> list = item;
        list.addAll(filesMap.tailMap("").values());
        this.path.addAll(dirsPathMap.tailMap("").values());
        this.path.addAll(filesPathMap.tailMap("").values());
        SimpleAdapter fileList = new SimpleAdapter(this, this.mList, R.layout.file_dialog_row, new String[]{ITEM_KEY, ITEM_IMAGE}, new int[]{R.id.fdrowtext, R.id.fdrowimage});
        for (String dir : dirsMap.tailMap("").values()) {
            addItem(dir, R.drawable.file_dialog_folder);
        }
        for (String file2 : filesMap.tailMap("").values()) {
            addItem(file2, getIcon(file2));
        }
        fileList.notifyDataSetChanged();
        listView.setAdapter(fileList);
    }

    private void addItem(String fileName, int imageId) {
        HashMap<String, Object> item = new HashMap<String,Object>();
        item.put(ITEM_KEY, fileName);
        item.put(ITEM_IMAGE, Integer.valueOf(imageId));
        this.mList.add(item);
    }
	public int getIcon(String str)
	{
		if (str.endsWith(".ovpn")) {
			return R.drawable.ovpn_file_icon;
		}
	  
	  return R.drawable.file_dialog_file;
	}

	@Override
    public void onItemClick(AdapterView<?> l, View v, int position, long id) {
        File file = new File((String) this.path.get(position));
        setSelectVisible(v);
        if (file.isDirectory()) {
            this.selectButton.setEnabled(false);
            if (file.canRead()) {
                this.lastPositions.put(this.currentPath, Integer.valueOf(position));
                getDir((String) this.path.get(position));
                if (this.canSelectDir) {
                    this.selectedFile = file;
                    v.setSelected(true);
                    this.selectButton.setEnabled(true);
                    return;
                }
                return;
            }
            Toast.makeText(this, "Can't read file Permission Not Granted", Toast.LENGTH_LONG).show();
            return;
        }
        this.selectedFile = file;
        v.setSelected(true);
        this.selectButton.setEnabled(true);
        showLocation(R.string.file_dialog_select, file.getPath());
        if (this.m_bOneClickSelect) {
            this.selectButton.performClick();
        }
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode != 4) {
            return super.onKeyDown(keyCode, event);
        }
        this.selectButton.setEnabled(false);
        if (this.layoutCreate.getVisibility() == 0) {
            this.layoutCreate.setVisibility(8);
            this.layoutSelect.setVisibility(MODE_CREATE);
        } else if (this.currentPath.equals(ROOT)) {
            return super.onKeyDown(keyCode, event);
        } else {
            getDir(this.parentPath);
        }
        return true;
    }

    private void setCreateVisible(View v) {
        this.layoutCreate.setVisibility(MODE_CREATE);
        this.layoutSelect.setVisibility(8);
        this.inputManager.hideSoftInputFromWindow(v.getWindowToken(), MODE_CREATE);
        this.selectButton.setEnabled(false);
    }

    private void setSelectVisible(View v) {
        if (!this.m_bOneClickSelect) {
            this.layoutCreate.setVisibility(8);
            this.layoutSelect.setVisibility(MODE_CREATE);
            this.inputManager.hideSoftInputFromWindow(v.getWindowToken(), MODE_CREATE);
            this.selectButton.setEnabled(false);
        }
    }
}
