package net.openvpn.openvpn;

import net.openvpn.openvpn.*;
import android.os.*;
import zed.freeudp.vpn.R;
import android.view.View.*;
import android.view.*;
import android.preference.*;
import android.content.*;
import android.content.SharedPreferences.*;
import android.widget.*;

public class LoginActivity extends MainBase implements OnClickListener
{
	public static final String USERNAME = "USERNAME_VPN";
	public static final String PASSWORD = "PASSWORD_VPN";
	public static final String NAME = "PROF_NAME";
	private SharedPreferences prefs;
	private SharedPreferences.Editor editor;
	private EditText username;
	private EditText password;
	private Button btn;
	private String name;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_activity);
		prefs = PreferenceManager.getDefaultSharedPreferences(this);
		editor = prefs.edit();
		
		username = (EditText)findViewById(R.id.username_vpn);
		password = (EditText)findViewById(R.id.password_vpn);
		btn = (Button)findViewById(R.id.account_login);
		
		name = getIntent().getStringExtra("PROF_NAME");
		username.setText(prefs.getString(name+USERNAME,""));
		password.setText(prefs.getString(name+PASSWORD,""));
		btn.setOnClickListener(this);
		
	}

	@Override
	public void onClick(View p1)
	{
		String user = username.getText().toString();
		String pass = password.getText().toString();
		if (user.isEmpty()) {
			toast("Username is empty");
		} else if (pass.isEmpty()) {
			toast("Password is empty");
		} else if (user.isEmpty() && pass.isEmpty()) {
			toast("Fields cannot be empty");
		} else {
			editor.putString(name+USERNAME, user).apply();
			editor.putString(name+PASSWORD, pass).apply();
			finish();
		}
		// TODO: Implement this method
	}

	private void toast(String p0)
	{
		Toast.makeText(this, p0, -1).show();
		// TODO: Implement this method
	}
	
}
