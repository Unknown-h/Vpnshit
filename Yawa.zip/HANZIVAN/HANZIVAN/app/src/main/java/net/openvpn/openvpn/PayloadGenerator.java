package net.openvpn.openvpn;

import android.support.v7.app.*;
import android.os.*;
import android.support.design.widget.*;
import android.view.View.*;
import android.view.*;
import android.content.*;
import android.widget.*;
import android.widget.CompoundButton.*;
import java.io.*;
import android.content.DialogInterface.*;
import android.preference.*;
import android.content.SharedPreferences.*;
import zed.freeudp.vpn.*;

public class PayloadGenerator extends MainBase implements OnClickListener
{
	private EditText url_host;
	private CheckBox online_host;
	private CheckBox forward_host;
	private CheckBox forwarded_for;
	private CheckBox keep_alive;
	private EditText proxy;
	private EditText port;
	private CheckBox pull;
	private CheckBox redirect;
	private Button export_button;
	private RelativeLayout proxyLay;
	private CheckBox useDefRp;
	private SharedPreferences prefs;
	private String name;
	public static String USE_DEF_PROXY = "DEFAULT_PROXY";
	private SharedPreferences.Editor editor;
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.abc_screen_material_default);
		
		url_host = (EditText)findViewById(R.id.url_host);
		online_host = (CheckBox)findViewById(R.id.online_host);
		forward_host = (CheckBox)findViewById(R.id.forward_host);
		forwarded_for = (CheckBox)findViewById(R.id.forwarded_for);
		keep_alive = (CheckBox)findViewById(R.id.keep_alive);
		proxy = (EditText)findViewById(R.id.remote_proxy);
		port = (EditText)findViewById(R.id.proxy_port);
		pull = (CheckBox)findViewById(R.id.option_pull);
		redirect = (CheckBox)findViewById(R.id.option_redirect_gateway);
		export_button = (Button)findViewById(R.id.export_button);
		proxyLay = (RelativeLayout)findViewById(R.id.proxy_layout);
		useDefRp = (CheckBox)findViewById(R.id.default_proxy);
		
		prefs = PreferenceManager.getDefaultSharedPreferences(this);
		editor = prefs.edit();
		name = getIntent().getStringExtra("PROFILE_NAME")+".ovpn";
		
		useDefRp.setChecked(prefs.getBoolean(name+USE_DEF_PROXY,false));
		pull.setChecked(prefs.getBoolean(Util.PULL_KEY, false));
		redirect.setChecked(prefs.getBoolean(Util.REDIRECT_KEY, false));
		online_host.setChecked(prefs.getBoolean(Util.ONLINE_HOST_KEY, false));
		forward_host.setChecked(prefs.getBoolean(Util.FORWARD_HOST_KEY, false));
		forwarded_for.setChecked(prefs.getBoolean(Util.FORWARDED_FOR_KEY, false));
		keep_alive.setChecked(prefs.getBoolean(Util.KEEP_ALIVE_KEY, false));
		url_host.setText(prefs.getString(Util.URL_HOST_KET, ""));
		proxy.setText(prefs.getString(name + Util.PROXY_KEY, ""));
		port.setText(prefs.getString(name + Util.PORT_KEY, ""));
		
		export_button.setOnClickListener(this);
		useDefRp.setOnCheckedChangeListener(onChecked());
		
	}

	private CompoundButton.OnCheckedChangeListener onChecked()
	{
		// TODO: Implement this method
		return new CompoundButton.OnCheckedChangeListener()
		{
			@Override
			public void onCheckedChanged(CompoundButton p1, boolean z)
			{
				String rp = Util.getRp(PayloadGenerator.this, name);
				proxy.setText(p1.isChecked() ? rp : "");
				port.setText(p1.isChecked() ? "8080" : "");
				editor.putBoolean(name+USE_DEF_PROXY, p1.isChecked() ? true: false).apply();
			}
			
		};
	}

	@Override
	public void onClick(View p1)
	{
		int id = p1.getId();
		if (id == R.id.export_button) {
		
			editor.putString(Util.URL_HOST_KET, url_host.getText().toString()).commit();
			editor.putString(name + Util.PROXY_KEY, proxy.getText().toString()).commit();
			editor.putString(name + Util.PORT_KEY, port.getText().toString()).commit();
			 if (pull.isChecked()) {
			  editor.putBoolean(Util.PULL_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.PULL_KEY, false).commit();
		   }  if (redirect.isChecked()) {
			  editor.putBoolean(Util.REDIRECT_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.REDIRECT_KEY, false).commit();
		   } if (online_host.isChecked()) {
			  editor.putBoolean(Util.ONLINE_HOST_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.ONLINE_HOST_KEY, false).commit();
		   } if (forward_host.isChecked()) {
			  editor.putBoolean(Util.FORWARD_HOST_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.FORWARD_HOST_KEY, false).commit();
		   } if (forwarded_for.isChecked()) {
			  editor.putBoolean(Util.FORWARDED_FOR_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.FORWARDED_FOR_KEY, false).commit();
		   } if (keep_alive.isChecked()) {
			  editor.putBoolean(Util.KEEP_ALIVE_KEY, true).commit();
		   } else {
			  editor.putBoolean(Util.KEEP_ALIVE_KEY, false).commit();
		   }
			String url = url_host.getText().toString();
			String crlf = "[crlf]";
			String sp = " ";
			String payload = "CONNECT [host_port][protocol]"+crlf+"Host:"+sp+url+crlf+headers(online_host.isChecked(),"X-Online-Host:",sp,url,crlf)+headers(forward_host.isChecked(),"X-Forwad-Host:",sp,url,crlf)+headers(forwarded_for.isChecked(),"X-Forwaded-For:",sp,url,crlf)+isKeppAlive(keep_alive.isChecked(),"Connection: Keep-Alive",crlf)+crlf;
			editor.putString("payload",payload).apply();
			finish();
		}
		// TODO: Implement this method
	}

	private String isKeppAlive(boolean isChecked, String p1, String crlf)
	{
		if (isChecked) {
			return p1+crlf;
		}
		// TODO: Implement this method
		return "";
	}

	private String headers(boolean isChecked, String p1, String sp,String url, String crlf)
	{
		if (isChecked) {
			return p1+sp+url+crlf;
		}
		// TODO: Implement this method
		return "";
	}
 

}
