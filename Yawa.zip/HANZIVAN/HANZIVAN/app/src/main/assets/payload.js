//Edit nyo lang ang payload then sa Url example m.facebook.com eencrypt nyo muna bago i-repalce
[
 
  {
	  "Name":"SUN-TU-PROMO",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"111.221.44.59",
			  "Port":"8080"
		  },
		  "Url":"da5ccededeced8ca5cc6deda",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  }
]
