//Edit nyo lang ang payload then sa Url example m.facebook.com eencrypt nyo muna bago i-repalce
[
 
  {
	  "Name":"SUN-TU-PROMO",
	  "Info":"Register to TU50",
	   "Payload":{
		  "Proxy":{
			  "Custom":true,
			  "Remote":"e9413.g.akamaiedge.net.viber.com.gandakoba.ok-dns.com",
			  "Port":"8080"
		  },
		  "Url":"ecd2c4cae45cc6deda",
		  "Host":true,
		  "Online-Host":true,
		  "Forward-Host":true,
		  "Reverse-Proxy":false,
		  "Keep-Alive":true
	  }
  }
]
